<?php

namespace UHC\Scenarios;

use UHC\Main;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\Player;

class Nofall implements Listener {
    
  public $scenarios;
  private $plugin;
  
  public function __construct(Main $plugin){
    $this->plugin = $plugin;
    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  }

  public function getPlugin(){
    return $this->plugin;
  }
  
  public function onDamage(EntityDamageEvent $event){
    
    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
    if($this->scenarios->get("nofall") == true) {
      if($event->getEntity() instanceof Player){
        if($event->getCause() === EntityDamageEvent::CAUSE_FALL){
          $event->setCancelled();
        }
      }
    }
  }
}