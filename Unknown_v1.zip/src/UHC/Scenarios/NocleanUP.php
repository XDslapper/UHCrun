<?php

namespace UHC\Scenarios;

use UHC\Main;
use pocketmine\event\Listener;
use pocketmine\entity\Effect;
use pocketmine\utils\Config;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\Player;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\utils\TextFormat as T;

class NocleanUP implements Listener {

  public $scenarios;
  private $plugin;
  
  public function __construct(Main $plugin){
    $this->plugin = $plugin;
    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  }

  public function getPlugin(){
    return $this->plugin;
  }
	
public function onDeath(PlayerDeathEvent $e){
	    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
    if($this->scenarios->get("nocleanup") == true) {
	$p = $e->getPlayer();
	$c = $p->getLastDamageCause();
	if($c instanceof EntityDamageByEntityEvent){
	$k = $c->getDamager();
	$v = $c->getEntity();
	if($k instanceof Player){
    $k->setHealth($k->getHealth() + 20);
	$re = Effect::getEffect(10);
	$re->setVisible(false);
	$re->setAmplifier(2);
	$re->setDuration(50);
	$k->addEffect($re);
	$k->sendMessage(T::DARK_AQUA."[TIP] ".T::GRAY."Has Sido regenerado");
	}
	}
	}
	}
	
	}