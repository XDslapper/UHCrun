<?php

namespace UHC\Scenarios;

use UHC\Main;
use pocketmine\event\Listener;
use pocketmine\utils\Config;

use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\entity\Entity;
use pocketmine\entity\Human;
use pocketmine\entity\PigZombie;
use pocketmine\entity\Zombie;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\tile\Skull;
use pocketmine\tile\Tile;
use pocketmine\utils\TextFormat;
use pocketmine\utils\UUID;
use pocketmine\event\player\PlayerDeathEvent;

class Statua implements Listener {

  public $scenarios;
  private $plugin;
  
  public function __construct(Main $plugin){
    $this->plugin = $plugin;
    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  }

  public function getPlugin(){
    return $this->plugin;
  }
	
	public function onDeath(PlayerDeathEvent $e){
	    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
    if($this->scenarios->get("statua") == true) {
        $player = $e->getPlayer();
    $level = $player->getLevel();
		$pos = $player->getPosition();
		$level->setBlock($pos->add(0, 1), Block::get(247), true);
		$level->setBlock($pos, Block::get(Block::NETHER_BRICK_FENCE));
	}
}

public function onBreak(BlockBreakEvent $e){
    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
    if($this->scenarios->get("statua") == true) {
if($e->getBlock()->getId() == 247){
	$e->setDrops([Item::get(397, 3, 1)]);
}
}
}
}


