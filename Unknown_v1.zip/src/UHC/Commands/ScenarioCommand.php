<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;
use pocketmine\entity\Entity;

class ScenarioCommand extends BaseCommand {

  public function __construct(Main $plugin) {
    $this->plugin = $plugin;
    $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
    parent::__construct($plugin, "scenario", "Main Host command!", "/scenario [add|rem|list]", ["sc"]);
  }
  
  public function execute(CommandSender $sender, $commandLabel, array $args) {
  if (count($args) < 1) {
  $sender->sendMessage(T::RED."Use /scenario [ add | rem | list ]");
  return true;
  }
  if($sender->isOp()){
  if (isset($args[0])) {
  switch ($args[0]) {
  case "add":
  switch ($args[1]){
   
   /*
   Estatua Deja Una Balla Con Una 
   Cabeza (Importante para La Golde Head)
   */

  case "statua":
  case "st":
  $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  if($this->scenarios->get("statua") === true){
  $sender->sendMessage("§cYa Has activado El escenario Statua");
  return;
  }else{
  $this->scenarios->set("statua", true);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§b Statua Activado");
  return true;
  }
  
  /*
  No CleanUP Cuando Matas Ha Algien
  Te Regenera Toda La Vida
  */

  case "nocleanup":
  case "nc":
  $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  if($this->scenarios->get("nocleanup") === true){
  $sender->sendMessage("§cYa Has activado El escenario NocleanUP");
  return;
  }else{
  $this->scenarios->set("nocleanup", true);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§b NocleanUP Activado");
  return true;
  }
  
  /*
  NoFall No Hay Daño por Caida
  */

  case "nofall":
  case "nf":
  if($this->scenarios->get("nofall") === true){
  $sender->sendMessage("§cYa Has activado El escenario Nofall");
  return;
  }else{
  $this->scenarios->set("nofall", true);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§b Nofall Activado");
  return true;
  }
  
  /*
  FireLess No Mueres Por Lava
  */

  case "fireless":
  case "fl":
  if($this->scenarios->get("fireless") === true){
  $sender->sendMessage("§cYa Has activado El escenario Fireless");
  return;
  }else{
  $this->scenarios->set("fireless", true);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§b Fireless Activado");
  return true;
  }
  }
  }
  }
  
  /*
  Todo Lo Que Sigue ↓↓ Es Para 
  Desactivar Los Scenarios
  */
  if($sender->isOp()){
  if (isset($args[0])) {
  switch ($args[0]) {
  case "rem":
  switch ($args[1]){

  case "statua":
  case "st":
  if($this->scenarios->get("statua") === false){
  $sender->sendMessage("§cYa Has Desactivado El Escenario Statua");
  return;
  }else{
  $this->scenarios->set("statua", false);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§c Statua Desactivado");
  return true;
  }

  case "nocleanup":
  case "nc":
  $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  if($this->scenarios->get("nocleanup") === false){
  $sender->sendMessage("§cYa Has Desactivado El Escenario NocleanUP");
  return;
  }else{
  $this->scenarios->set("nocleanup", false);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§c NocleanUP Desactivado");
  return true;
  }

  case "nofall":
  case "nf":
  if($this->scenarios->get("nofall") === false){
  $sender->sendMessage("§cYa Has Desactivado El Escenario Nofall");
  return;
  }else{
  $this->scenarios->set("nofall", false);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§c Nofall Desactivado");
  return true;
  }

  case "fireless":
  case "fl":
  if($this->scenarios->get("fireless") === false){
  $sender->sendMessage("§cYa Has Desactivado El Escenario Fireless");
  return;
  }else{
  $this->scenarios->set("fireless", false);
  $this->scenarios->save();
  $this->scenarios->reload();
  $sender->sendMessage("§7»§c Fireless Desactivado");
  return true;
  }
  }
  }
  }
  
  /*
 Mirar Los Scenarios 
  Disponibles 
  */
  if($sender->isOp()){
  if (isset($args[0])) {
  switch ($args[0]) {
  case "list":
  if($sender->isOp()){
  $sender->sendMessage("§7»§3 nofall §7| nf");
  $sender->sendMessage("§7»§3 fireless §7| fl");
  $sender->sendMessage("§7»§3 nocleanup §7| nc");
  $sender->sendMessage("§7»§3 statua §7| st");
  }
  }
  }
  }
  if (isset($args[0])) {
  switch ($args[0]) {
  case "ratas":
 if($sender->isOp()){
	foreach($this->plugin->getServer()->getOnlinePlayers() as $py){
	$py->setDataProperty(Entity::DATA_SCALE, Entity::DATA_TYPE_FLOAT, 0.6);
  $py->sendMessage(T::GRAY."Ahora Eres Una Rata");
} 
} 
}
}

if (isset($args[0])) {
  switch ($args[0]) {
  case "normal":
 if($sender->isOp()){
	foreach($this->plugin->getServer()->getOnlinePlayers() as $py){
	$py->setDataProperty(Entity::DATA_SCALE, Entity::DATA_TYPE_FLOAT, 1);
  $py->sendMessage(T::GRAY."Ahora Eres Normal");
	}
	}
	}
  }



  }
  }
  }
  }