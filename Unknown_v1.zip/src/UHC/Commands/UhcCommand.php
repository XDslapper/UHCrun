<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;
use pocketmine\entity\Entity;

class UhcCommand extends BaseCommand {
 
  public function __construct(Main $plugin) {
  $this->plugin = $plugin;
  parent::__construct($plugin, "uhc", "UHC Command!", "/uhc help | ?", ["uhc"]);
  }
  
  public function execute(CommandSender $sender, $commandLabel, array $args){
  $positions = new Config($this->plugin->getDataFolder()."Positions.yml", Config::YAML);
  $options = new Config($this->plugin->getDataFolder()."Options.yml", Config::YAML);
  if(isset($args[0])){
 // if(isset($args[1])){
  switch($args[0]){
  	
  case "?":
  case "help":
  if($sender->isOp()){
  $this->UHCHelp($sender);
  }
  break;
  
  case "start":
  $plugin = $this->plugin;
  if($sender->isOp()){
  foreach($plugin->getServer()->getOnlinePlayers() as $pl){
  $plugin->status = Main::STATUS_COUNTDOWN;
  $plugin->getServer()->getOfflinePlayer($pl->getName())->setWhitelisted(true);
  $plugin->getServer()->setConfigBool("white-list", true);
  $plugin->kills[$pl->getName()] = 0;
  $pl->sendMessage(T::GREEN."[TIP] ".T::AQUA.$sender->getName().T::GRAY." Ha Empezado El UHC-MEETUP");
  }
  }
  break;
  
  case "stop":
  $plugin = $this->plugin;
  foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
  $player->teleport($plugin->getServer()->getDefaultLevel()->getSafeSpawn());
  $player->removeAllEffects();
  $health = $player->getMaxHealth();
  $hunger = $player->getMaxFood();
  $player->setFood($hunger);
  $player->setHealth($health);
 // $this->plugin->Stop();
  $player->sendMessage(T::GRAY."El Event Ha sido Cancelado!!");
  }
  break;

  case "grace":
  $plugin = $this->plugin;
  if($sender->isOp()){
  $plugin->status = Main::STATUS_GRACE;
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Has Empezado Grace");
  }
  break;

  case "pvp":
  $plugin = $this->plugin;
  if($sender->isOp()){
  $plugin->status = Main::STATUS_PVP;
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Has Empezado El PvP");
  }
  break;

  case "tp":
  $plugin = $this->plugin;
  if($sender->isOp()){
  $plugin->status = Main::STATUS_TP_1;
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY." Has Empezado El Tpall");
  }
  break;

  case "clear":
  $plugin = $this->plugin;
  if($sender->isOp()){
  foreach($plugin->getServer()->getOnlinePlayers() as $pi){
  $pi->getInventory()->clearAll();
  $pi->setHealth(20);
  if($pi->isOp()){
  }else{
  $pi->setGamemode(0);
  }
  $pi->setFood(20);
  $pi->removeAllEffects();
  $pi->sendMessage(T::GREEN."[TIP] ".T::GRAY." Su Inventario Ha sido Reseteado!");
  }
  }
  break;

  case "set":
  if($sender->isOp()){
  if($args[1] == "uhc"){
  $level = $sender->getLevel()->getName();
  $positions->set("uhc", array($sender->getFloorX(), $sender->getFloorY(), $sender->getFloorZ()));
  $positions->save();
  $positions->reload();
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Se establecido la posicion UHC correctamente!");
  }
  else if($args[1] == "meetup"){
  $positions->set("meetup", array($sender->getFloorX(), $sender->getFloorY(), $sender->getFloorZ()));
  $positions->save();
  $positions->reload();
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Se establecio la posicion UHC-MEETUP correctamente");
  }
  }
  break;

  case "auto":
  $plugin = $this->plugin;
  if($sender->isOp()){
  if($args[1] == "meetup"){
  $plugin->StartMeet();
  $plugin->Math();
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY." Empezando Nuevo UHC-MEETUP");
  }
  else if($args[1] == "uhc"){
  $plugin->StartUHC();
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY." Se Ha Establesido Corretamente el UHC Ahora Use /uhc start para Empezar");
  }
  else if($args[1] == "mee"){
  $plugin->StartMeetrand();
  $plugin->Math();
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY." Empezando Nuevo UHC - MEETUP");
  }
  }
  break;
	
  case "life":
  $plugin = $this->plugin;
  if($sender->isOp()){
  foreach($plugin->getServer()->getOnlinePlayers() as $pa){
  $pa->setHealth(20);
  $pa->setFood(20);
  $pa->sendMessage(T::GREEN."[TIP] ".T::GRAY."Su vida Ha Sido Regenerada");
  }
  }
  break;
	
  case 'tpall':
  $plugin = $this->plugin;
  if($sender->isOp()){
  foreach($plugin->getServer()->getOnlinePlayers() as $pl){
  $pl->teleport($sender->getLocation());
  $pl->sendMessage(T::GREEN."[TIP] ".T::GRAY.$sender->getName()." Ha Realizado Un Tpall");
  }
  }
  break;

  case "respawn":
  if($sender->isOp()){
  $pl = $this->plugin->getServer()->getPlayer($args[1]);
  $this->plugin->getServer()->broadcastMessage(T::GRAY." Respawn ha ".T::AQUA.$pl->getName());
  $this->plugin->Restore($pl);
  }
  break;

  case 'huball':
  $plugin = $this->plugin;
  if($sender->isOp()){
  foreach($plugin->getServer()->getOnlinePlayers() as $pl){
  $sender->teleport($plugin->getServer()->getDefaultLevel()->getSafeSpawn());
  $pl->sendMessage(T::GREEN."[TIP] ".T::GRAY."Fuiste teletransportado al Spawn");
  }
  }
  break;
	
  case 'hub':
  $plugin = $this->plugin;
  if($sender->isOp()){
  $sender->teleport($plugin->getServer()->getDefaultLevel()->getSafeSpawn());
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Te has Teletransportado al Spawn");
  }
  break;
  
  }
  }
  }
//  }
  
  
  
  
 public function UHCHelp(CommandSender $sender){
 $sender->sendMessage(T::RED."BlueCraft".T::RED."UHCs".T::GOLD." CoreUHC");
 $messages = [
 "auto uhc" => "Empiza Nuevo UHC",
 "auto meetup" => "Empieza Nuevo UHC Meetup KIT NORMAL",
 "auto mee" => "Empieza Nuevo UHC Meetup Kit Random",
 "set uhc o meetup" => "Selecciona Lugar Donde Se Hara Tp auto",
 "tpall" => "Teletranspprta Los Jugadores Hacia Ti",
 "huball" => "Teletransporta Los Jugadores al Spawn",
 "hub" => "TeleTranspprta Al HUB (Solo Ops)",
 "life" => "Regenera La Vida De Todos",
 "respawn (player)" => "Respawn Ha un Jugador"
 ];
 foreach($messages as $name => $message) {
 $sender->sendMessage(T::DARK_AQUA."/uhc {$name} ".T::GRAY.$message);
 }
 $sender->sendMessage(T::GRAY."-- COMANDOS APARTE --\n");
 $sender->sendMessage(T::DARK_AQUA."/scenario");
 $sender->sendMessage(T::DARK_AQUA."/stats");
 $sender->sendMessage(T::DARK_AQUA."/kt");
 $sender->sendMessage(T::DARK_AQUA."/borde");
 $sender->sendMessage(T::DARK_AQUA."/globalmute");
 $sender->sendMessage(T::DARK_AQUA."/proteccion");
 $sender->sendMessage(T::DARK_AQUA."/pvp");
 $sender->sendMessage(T::DARK_AQUA."/Spect");
 $sender->sendMessage(T::DARK_AQUA."/Tpa");
 $sender->sendMessage(T::DARK_AQUA."/rank Rango (player)");
 }

 }
				
				
				