<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\network\protocol\SetDifficultyPacket;

class ProteCommand extends BaseCommand {
  
  public $plugin;
  
  public function __construct(Main $plugin) {
  $this->plugin = $plugin;
  parent::__construct($plugin, "proteccion", "use /proteccion [ on | off ]", "/protección", ["pt"]);
  }
  
  public function execute(CommandSender $sender, $commandLabel, array $args) {
  if (count($args) < 1) {
  $sender->sendMessage(T::RED."Use /proteccion [ On | Off ]");
  return true;
  }

  if($sender->isOp()){
  foreach($this->plugin->getServer()->getOnlinePlayers() as $pl){
  if($args[0] == "on"){
  $this->plugin->break = false;
  $pl->sendMessage(T::GREEN."[TIP] ".T::GRAY."La Proteccion Ha Sido Activada");
  }else if($args[0] == "off"){
  $this->plugin->break = true;
  $pl->sendMessage(T::GREEN."[TIP] ".T::GRAY."La Proteccion Ha Sido Desactivada");
  }
  }
  }
  }
  }