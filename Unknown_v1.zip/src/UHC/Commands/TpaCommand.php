<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\IPlayer;
use pocketmine\event\Listener;
use pocketmine\event\Timings;
use pocketmine\level\format\FullChunk;
use pocketmine\level\format\LevelProvider;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector2;
use pocketmine\math\Vector3;
use pocketmine\math\AxisAlignedBB;
use pocketmine\plugin\Plugin;
use pocketmine\utils\ReversePriorityQueue;

class TpaCommand extends BaseCommand {
  
  public $plugin;
  
  public function __construct(Main $plugin) {
  $this->plugin = $plugin;
  parent::__construct($plugin, "tpa", "tpa [accept | deny] ", "/tpa", []);
  }
  
  public function execute(CommandSender $sender, $commandLabel, array $args) {
  if (count($args) < 1) {
  $sender->sendMessage(T::RED."Use /tpa [ 'player' | accept | deny ]");
  return true;
  }

  if($sender instanceof Player){
  if(isset($args[0])){
  $name = strtolower($sender->getPlayer()->getName());
  if($target = $sender->getServer()->getPlayer($args[0])){
  $targetname = strtolower($sender->getServer()->getPlayer($args[0])->getName());
  
  $sender->getServer()->getPlayer($args[0])->sendMessage(T::DARK_AQUA."[TIP] ".T::GOLD.$name.T::GRAY." Te ha enviado solicitud de Tpa");
  $sender->getServer()->getPlayer($args[0])->sendMessage(T::DARK_AQUA."/tpa accept".T::GRAY." | Para Confirmar\n".T::DARK_AQUA."/tpa deny".T::GRAY." | Para Rechazar");
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Tu solicitud de Tpa ha sido Enviada!");
  $this->tpa[$targetname] = $name;
  }
  }
  
  if (isset($args[0])) {
  switch ($args[0]) {
  case "accept":
  $name = strtolower($sender->getName());
  if($this->tpa[$name] != null){
  $ziel = $this->tpa[$name];
  $target = $sender->getServer()->getPlayer($ziel);
  $pos = new Position($sender->x, $sender->y, $sender->z, $sender->getLevel());
  $target->teleport($pos);
  $sender->getServer()->getPlayer($ziel)->sendMessage(T::GREEN."[TIP] ".T::GRAY."Teletransportando..");
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Solicitud Tpa aceptada");
  }
  return true;

  case "deny":
  $name = strtolower($sender->getName());
  if($this->tpa[$name] != null){
  $ziel = $this->tpa[$name];
  $sender->getServer()->getPlayer($ziel)->sendMessage(T::DARK_AQUA."[TIP] ".T::GRAY."Solicitud de Tpa rechazada");
  $sender->sendMessage(T::GREEN."[TIP] ".T::GRAY."Tu Solicitud de Tpa Ha sido rechazada");
  }	
  return true;
  }
  }
  }
  }
  }