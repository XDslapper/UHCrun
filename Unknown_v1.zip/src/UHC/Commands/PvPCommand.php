<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\network\protocol\SetDifficultyPacket;

class PvPCommand extends BaseCommand {
  
  public $plugin;
  
  public function __construct(Main $plugin) {
  $this->plugin = $plugin;
  parent::__construct($plugin, "pvp", "use /pvp [ on | off ]", "/pvp", []);
  }
  
  public function ActivePvP(){
  $plugin = $this->plugin;
  $plugin->getServer()->setConfigInt("difficulty", 1);
  $pk = new SetDifficultyPacket();
  $pk->difficulty = $plugin->getServer()->getDifficulty();
  }
	
  public function DisablePvP(){
  $plugin = $this->plugin;
  $plugin->getServer()->setConfigInt("difficulty", 0);
  $pk = new SetDifficultyPacket();
  $pk->difficulty = $plugin->getServer()->getDifficulty();
	 }
  
  public function execute(CommandSender $sender, $commandLabel, array $args) {
  if (count($args) < 1) {
  $sender->sendMessage(T::RED."Use /pvp [ On | Off ]");
  return true;
  }

  if($sender->isOp()){
  foreach($this->plugin->getServer()->getOnlinePlayers() as $pl){
  if($args[0] == "on"){
  $this->ActivePvP();
  $pl->sendMessage(T::GREEN."[TIP] ".T::GRAY."El PvP Ha Sido Activado");
  }else if($args[0] == "off"){
  $this->DisablePvP();
  $pl->sendMessage(T::GREEN."[TIP] ".T::GRAY."El PvP Ha Sido Desactivado");
  }
  }
  }
  }
  }