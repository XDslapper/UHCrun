<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;

class ScenariosCommand extends BaseCommand {
  
  public $plugin;
  public $scenarios;
  
  public function __construct(Main $plugin) {
  $this->plugin = $plugin;
  parent::__construct($plugin, "scenarios", "See uhc scenarios", "/scenarios", []);
  }
  
  public function execute(CommandSender $sender, $commandLabel, array $args) {
  $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
  
  $sender->sendMessage(T::GOLD."Escenarios");


  if($this->scenarios->get("nofall") === true){
  $sender->sendMessage(T::GRAY."- NoFall");
  }
    
  if($this->scenarios->get("fireless") === true){
  $sender->sendMessage(T::GRAY."- Fireless");
  }

  if($this->scenarios->get("nocleanup") === true){
  $sender->sendMessage(T::GRAY."- NocleanUP");
  }

  if($this->scenarios->get("statua") === true){
  $sender->sendMessage(T::GRAY."- Statua");
  }

  if($this->scenarios->get("spiderbow") === true){
  $sender->sendMessage(T::GRAY."- SpiderBow");
  }
  }
  
  public function getPlugin(){
  return $this->plugin;
  }
  }
  