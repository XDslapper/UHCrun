<?php

namespace UHC\Commands;

use UHC\Main;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as T;
use pocketmine\utils\Config;
use pocketmine\Server;
use pocketmine\network\protocol\SetDifficultyPacket;

class rankCommand extends BaseCommand {
  
  public $plugin;
  
  public function __construct(Main $plugin) {
  $this->plugin = $plugin;
  parent::__construct($plugin, "rank", "use /rank ", "/rank", []);
  }
  
  public function execute(CommandSender $player, $commandLabel, array $args) {
  if($player->isOp()){
  if(!empty($args[0])){
  if(!empty($args[1])){
  $rank = new Config($this->plugin->getDataFolder() . "/rank.yml", Config::YAML);
  if($args[0]=="owner"){
  $r = T::YELLOW."[Owner]";
  }
  else if($args[0]=="host"){
  $r = T::BLUE."[Host]";
  }
  else if($args[0]=="f+"){
  $r = T::DARK_PURPLE."[F]";
  }
  else if($args[0]=="f"){
  $r = T::LIGHT_PURPLE."[Famous]";//$name = implode(" ", $args);
  } else {
  goto fin;
  }
  $jug = $this->plugin->getServer()->getPlayer($args[1]);
  if($jug!=null){
  $player->sendMessage(T::GRAY.$jug->getName()." obtuvo: ".$r);
  $jug->sendMessage(T::GRAY."Has Obtenido ".$r.T::GRAY." By ".$player->getName());
  $rank->set($jug->getName(), $r);
  $rank->save();
  } else {
  $player->sendMessage(T::GRAY."Dando rango ".$r.T::GRAY." sin estar online a ".$args[1]);
  $rank->set($args[1], $r);
  $rank->save();
  }
  fin:
  }
  } else {
  $player->sendMessage(T::GRAY."Uso: /rank <rank> <player>");
  }
  }
  }
  }