<?php

namespace UHC;

use UHC\Commands\UhcCommand;
use UHC\Commands\TpaCommand;
use UHC\Commands\PvPCommand;
use UHC\Commands\ProteCommand;
use UHC\Commands\ScenarioCommand;
use UHC\Commands\ScenariosCommand;
use UHC\Commands\rankCommand;

use UHC\Main;
use pocketmine\event\Listener;

class CommandRegister {

    public $plugin;

    public function __construct(Main $main) {
        $this->plugin = $main;
        $this->init();
    }

    private function init() {
        $commandMap = $this->plugin->getServer()->getCommandMap();
        $commandMap->registerAll("uhc", [
            new TpaCommand($this->plugin),
            new PvPCommand($this->plugin),
            new ProteCommand($this->plugin),
            new ScenarioCommand($this->plugin),
            new ScenariosCommand($this->plugin),
            new rankCommand($this->plugin),
            new UhcCommand($this->plugin),
        ]);
    }
}