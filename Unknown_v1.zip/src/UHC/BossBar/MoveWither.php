<?php

namespace UHC\BossBar;

use pocketmine\plugin\PluginBase;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\network\protocol\MoveEntityPacket;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\DataPacket;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\entity\Entity;
use pocketmine\Player;
use pocketmine\level\Location;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat as TF;
use UHC\Main;

class MoveWither extends PluginTask {
  
    public function __construct(Main $plugin){
        $this->plugin = $plugin;
        parent::__construct($plugin);
    }
  
    public function onRun($tick){
      
        $pk = new MoveEntityPacket();
        $pk->eid = 9272;
        $pk->yaw = 0;
        $pk->headYaw = 0;
        $pk->pitch = 0;
        foreach($this->getOwner()->getServer()->getOnlinePlayers() as $p){
            $pk->x = $p->x;
            $pk->y = $p->y - 28;
            $pk->z = $p->z;
            $p->dataPacket($pk);
        }
    }
}