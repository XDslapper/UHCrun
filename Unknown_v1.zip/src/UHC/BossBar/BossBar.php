<?php

namespace UHC\BossBar;

use UHC\Main;
use pocketmine\item\Item;
use pocketmine\network\protocol\AddPlayerPacket;
use sys\jordan\utils\BossEventPacket;
use pocketmine\network\protocol\MovePlayerPacket;
use pocketmine\network\protocol\SetEntityDataPacket;
use pocketmine\Player;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\Server;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\entity\Entity;
use pocketmine\utils\UUID;

class BossBar {

	private $plugin;

	public function __construct(Main $plugin){
		$this->plugin = $plugin;
	}


}