<?php

namespace UHC\TimeTask;

use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat as T;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\entity\Effect;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\Server;
use pocketmine\math\Vector3;
use pocketmine\network\protocol\SetDifficultyPacket;
use pocketmine\utils\Config;
use UHC\Main;
use pocketmine\level\sound\AnvilFallSound;
use pocketmine\level\sound\GhastSound;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\PopSound;
    
class StartUHC extends PluginTask{

  public $countdown = 1 * 20;
  public $grace = 60 * 60;
	
	 public function __construct(Main $plugin){
	 parent::__construct($plugin);
     $this->plugin = $plugin;
	 }

     public function time($int) {
     $m = floor($int / 60);
     $s = floor($int % 60);
     return (($m < 10 ? "0" : "") . $m . ":" . ($s < 10 ? "0" : "") . $s);
     }
	
	 public function ActivePvP(){
	 $plugin = $this->plugin;
	 $plugin->getServer()->setConfigInt("difficulty", 1);
	 $pk = new SetDifficultyPacket();
	 $pk->difficulty = $plugin->getServer()->getDifficulty();
	 }
     
		
	 public function onRun($currentTick){
     $options = new Config($this->plugin->getDataFolder()."Options.yml", Config::YAML);
     $positions = new Config($this->plugin->getDataFolder()."Positions.yml", Config::YAML);
     if ($this->plugin->status === Main::STATUS_WAITING) {
     $this->handleWaiting();
     $this->countdown = 1 * 20;
     $this->grace = 60 * 60;
     }
     if($this->plugin->status === Main::STATUS_COUNTDOWN){
     $this->handleCountdown();
     }
     if($this->plugin->status === Main::STATUS_GRACE){
     $this->handleGrace();
     }
     $this->vida();
     }
     

     public function handleWaiting(){
     foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
 	$players = count($this->plugin->getServer()->getOnlinePlayers());
     $player->sendPopup(T::AQUA."UHC-MEETUP".T::GRAY." Online Players [".T::DARK_AQUA.$players.T::GRAY."]");
     }
     }
     
     public function handleCountdown(){
     $options = new Config($this->plugin->getDataFolder()."Options.yml", Config::YAML);
     $positions = new Config($this->plugin->getDataFolder()."Positions.yml", Config::YAML);
     $this->scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");
     $this->countdown--;
     foreach($this->plugin->getServer()->getOnlinePlayers() as $pl){
     $max = 1 * 20;
     $pl->sendPopup(T::GREEN."El UHC-MEETUP Start In ".T::YELLOW.$this->time($this->countdown).T::GREEN." Seconds\n        ".T::YELLOW.str_repeat("|",$this->countdown).T::GREEN.str_repeat("|",$max - $this->countdown));
     if($this->countdown === 15) {
     $pl->setGamemode(0);
     $pl->setFood(20);
     $pl->setHealth(20);
     $inv = $pl->getInventory();
     $inv->clearAll();
     $inv->setHelmet(Item::get(310, 0, 1));
     $inv->setChestplate(Item::get(311, 0, 1));
     $inv->setLeggings(Item::get(312, 0, 1));
     $inv->setBoots(Item::get(313, 0, 1));
     $inv->setItem(0, Item::get(276, 0, 1));
     $inv->setItem(1, Item::get(279, 0, 1));
     $inv->setItem(2, Item::get(278, 0, 1));
     $inv->setItem(3, Item::get(322, 0, 15));
     $inv->setItem(4, Item::get(364, 0, 64));
     $inv->setItem(5, Item::get(5, 0, 64));
     $inv->setItem(6, Item::get(1, 0, 64));
     $pl->sendMessage(T::GOLD."[UHC-MEETUP]".T::YELLOW." Se Dio KIT !");
     }
     }
     if($this->countdown === 10) {
     $this->getOwner()->getServer()->broadcastMessage(T::GRAY."  [".T::RED."Scenarios Activos".T::GRAY."]");
     $pl->getLevel()->addSound(new AnvilUseSound($pl));
     if($this->scenarios->get("nofall") === true){
     $this->getOwner()->getServer()->broadcastMessage(T::GOLD."- NoFall");
     }
     if($this->scenarios->get("fireless") === true){
     $this->getOwner()->getServer()->broadcastMessage(T::GOLD."- Fireless");
     }
     if($this->scenarios->get("nocleanup") === true){
     $this->getOwner()->getServer()->broadcastMessage(T::GOLD."- NocleanUP");
     }
     if($this->scenarios->get("statua") === true){
     $this->getOwner()->getServer()->broadcastMessage(T::GOLD."- Statua");
     }
     if($this->countdown === 50) {
     $options->save();
	 $options->reload();
	 $pl->sendMessage(T::DARK_AQUA."[TIP]".T::GRAY." Estamos En Beta");
	 }
	 }
	 if($this->countdown === 5) {
     $this->getOwner()->getServer()->broadcastMessage(T::GRAY."---".T::AQUA." Follow ".T::BLUE."@BlueCraftUHCs ".T::GRAY."---");
	 }
     if($this->countdown === 0){
	 $this->getOwner()->getServer()->broadcastMessage(T::GOLD."[TIP]".T::GRAY." 12. El UHC-MEETUP HA EMPEZADO!");
     $this->plugin->break = true;
     $this->plugin->status = Main::STATUS_GRACE;
     
     }
     return;
     }
            
     public function handleGrace(){
     $options = new Config($this->plugin->getDataFolder()."Options.yml", Config::YAML);
     $positions = new Config($this->plugin->getDataFolder()."Positions.yml", Config::YAML);
     $scenarios = new Config($this->plugin->getDataFolder() . "scenarios.yml");

     $this->grace--;
     foreach($this->plugin->getServer()->getOnlinePlayers() as $pl) {
     if($scenarios->get("cateyes") == true) {
	 $pl->addEffect(Effect::getEffect(Effect::NIGHT_VISION)->setDuration(1000000)->setVisible(false));
	 }
     $colores = array(T::DARK_AQUA);
     $rand1 = $colores[array_rand($colores)];
     $colors = array(T::DARK_AQUA);
     $rand2 = $colors[array_rand($colors)];
     $es = str_repeat(" ", 70);
     $center = Server::getInstance()->getDefaultLevel()->getSafeSpawn();

     $pl->sendPopup($es.T::AQUA."UHC-MEETUP".$rand2."\n".T::GRAY.$es."Players Alive ".$rand2.$this->plugin->vivos()."\n".T::GRAY.$es.$a."Spectators ".$rand2.$i.$this->plugin->spect()."\n\n\n\n\n\n\n\n\n\n\n");
     $msg1 = T::GRAY."\n\nGame Ends In ";
     $time = $this->grace;
     $this->plugin->addBossBar($pl, $msg1, $time);
     }
     }

     public function vida(){
     foreach($this->plugin->getServer()->getOnlinePlayers() as $pl){
     $name = $pl->getName();
     $health = $pl->getHealth();
     $times = strlen($name)/2;
     if($times >= 4){
     $times+=1;
     }
     $spaces = str_repeat(" ", $times);
     $pl->setNameTag(T::AQUA.$name.PHP_EOL.$spaces.T::WHITE.$health.T::RED."HP");
     }
     }


	}