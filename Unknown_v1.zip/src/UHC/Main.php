<?php

namespace UHC;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\tile\Chest;
use pocketmine\utils\TextFormat as T;
use pocketmine\entity\Effect;
use pocketmine\network\protocol\SetDifficultyPacket;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\network\protocol\MoveEntityPacket;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\AddPlayerPacket;
use pocketmine\network\protocol\SetEntityDataPacket;
use pocketmine\network\protocol\DataPacket;
use pocketmine\utils\UUID;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\PluginTask;
use pocketmine\scheduler\Task;
use pocketmine\nbt\tag\ListTag;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Human;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerKickEvent;
use pocketmine\level\Position;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\permission\Permission;
use pocketmine\item\Item;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\BlazeShootSounduse;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\inventory\BigShapedRecipe;
use pocketmine\inventory\ShapedRecipe;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\server;
use pocketmine\item\Bucket;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\level\sound\ClickSound;
use pocketmine\event\player\PlayerCommandPreprocessEvent;

//BOSSBAR
use UHC\BossBar\BossEventPacket;
use UHC\BossBar\BossBar;
use UHC\BossBar\MoveWither;
use UHC\BossBar\BossHealth;

//TIMETAKS
use UHC\TimeTask\StartUHC;

//COMMANDS
use UHC\Command\HostCommand;
use UHC\Command\TpaCommand;
use UHC\Command\PvPCommand;
use UHC\Commands\ProteCommand;
use UHC\Commands\ScenarioCommand;
use UHC\Commands\ScenariosCommand;
use UHC\Commands\rankCommand;
use UHC\Commands\UhcCommand;

//SCENARIOS 
use UHC\Scenarios\NoFall;
use UHC\Scenarios\Fireless;
use UHC\Scenarios\NocleanUP;
use UHC\Scenarios\Statua;

class Main extends PluginBase implements Listener{
	

    const PREFIX = T::DARK_GRAY."[".T::RED." TimeBomb ".T::DARK_GRAY."] ".T::RESET;
    const STATUS_WAITING = -1;
    const STATUS_COUNTDOWN = 0;
    const STATUS_GRACE = 1;
    const STATUS_PVP = 2;
    const STATUS_TP_1 = 3;
    
    public $killer;
    public $kills = array();
    public $pos = [];
    public $inventory = [];
    
    private $playerData = array();
    private $level;
    private $position;
    private $attachments = [];

    public function  onEnable(){
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->sendCommands();
    $this->sendScenarios();
    $this->getServer()->getLogger()->info(T::GOLD."
  _   _ _   _  ____\n | | | | | | |/ ___|\n | | | | |_| | |    \n | |_| |  _  | |___ \n  \___/|_| |_|\____|");
    @mkdir($this->getDataFolder());
    @mkdir($this->getDataFolder() . "players/");

    $positions = new Config($this->getDataFolder()."Positions.yml", Config::YAML);
    $positions->save();
    
    $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
    $rank->save();

    $scenarios = new Config($this->getDataFolder()."scenarios.yml", Config::YAML, [
    "nofall" => false,
    "fireless" => false,
    "nocleanup" => false,
    "statua" => false,
    ]);
    $scenarios->save();

    $this->getLogger()->notice(T::GRAY."UHC Cargado");
    }
   
    public function sendCommands() {
    new CommandRegister($this);
    }
    
    public function getBossBar(){
	new BossBar($this);
    }
    
    public function sendScenarios() {
    $this->getServer()->getPluginManager()->registerEvents(new NoFall($this), $this);
    $this->getServer()->getPluginManager()->registerEvents(new Fireless($this), $this);
    $this->getServer()->getPluginManager()->registerEvents(new NocleanUP($this), $this);
    $this->getServer()->getPluginManager()->registerEvents(new Statua($this), $this);
    }
    
    
    
   /*
    * Task UHC
    */
    public function StartUHC(){
	$this->getServer()->getScheduler()->scheduleRepeatingTask(new StartUHC($this), 35)->getTaskId();
	}

  /*public function Stop(){
  $this->getServer()->getScheduler()->cancelTask($this->getTaskId());
   }*/

    public function DisablePvP(){
	$this->getServer()->setConfigInt("difficulty", 0);
	$pk = new SetDifficultyPacket();
	$pk->difficulty = $this->getServer()->getDifficulty();
	}

    public function vivos(){
    $vida = 0;
    foreach(Server::getInstance()->getOnlinePlayers()  as $heal){
    if($heal->getGamemode() == 0){
    $vida++;
    }
    }
    return $vida;
    }

    public function spect(){
    $spec = 0;
    foreach(Server::getInstance()->getOnlinePlayers()  as $k){
    if($k->getGamemode() == 3){
    $spec++;
    }
    }
    return $spec;
    }

    public function NoCraft(CraftItemEvent $e){
    $item = $e->getRecipe()->getResult();
    if($item instanceof Item){
    if($item instanceof Bucket){
    $e->setCancelled(true);
    $e->getPlayer()->sendMessage(T::GREEN."[TIP] ".T::GRAY."Los Bucket Estan OFF");
    }
    }
    }
	
    public function onPreLogin(PlayerPreLoginEvent $e){
    $p = $e->getPlayer();
    if(!$this->getServer()->isWhitelisted($p->getName())){
    $e->setCancelled();
    $e->setKickMessage(T::AQUA.$p->getPlayer()->getName().T::GRAY."\nLa Whitelist Ha Sido Activada");
    }
    }
	
	public function Backup(Player $player){
	$contents = $player->getInventory()->getContents();
	$items = [];
	foreach($contents as $slot => $item){
	$items[$slot] = [$item->getId(), $item->getDamage(), $item->getCount()];
	}
	$this->inventory[$player->getName()] = $items;
	}
	
	public function Restore(Player $player){
	$cloud = $this->inventory[$player->getName()];
	$player->getInventory()->clearAll();
	foreach($cloud as $slot => $item){
	$player->getInventory()->setItem($slot, Item::get($item[0], $item[1], $item[2]));
	}
	unset($this->inventory[$player->getName()]);
	return true;
	}
    
    public function getAttachment(Player $player){
    if(!isset($this->attachments[$player->getName()])){
    $this->attachments[$player->getName()] = $player->addAttachment($this);
	}
	return $this->attachments[$player->getName()];
	}
    
	
    public function onJoin(PlayerJoinEvent $event){
	$player = $event->getPlayer();
	$gm = $player->getGamemode();
    $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
    $r = $rank->get($player->getName());
    if(($r == T::LIGHT_PURPLE."[FAMOUS]")||($r == T::DARK_PURPLE."[F]")){ 
    $attachment = $this->getAttachment($player);
    $attachment->setPermission("globalmute", true);
    $attachment->setPermission("spam", true);
    }
	if(isset($this->pos[$player->getName()])){
    $player->teleport($this->pos[$player->getName()]);
    unset($this->pos[$player->getName()]);
    }
	if($gm = 3){
	$player->setGameMode(0);
	}
	$event->setJoinMessage("");
	$this->getServer()->broadcastMessage(T::GRAY."[".T::AQUA."+".T::GRAY."]".T::GRAY." ". $player->getName());
    }
	
    public function onQuit(PlayerQuitEvent $event){
	$player = $event->getPlayer();
	if(!isset($this->pos[$player->getName()])){
    $this->pos[$player->getName()] = clone $player->getPosition();
	$event->setQuitMessage("");
	$this->getServer()->broadcastMessage(T::GRAY."[".T::RED."-".T::GRAY."]".T::GRAY." ". $player->getName());
	}
	}

    public function onBreak(BlockBreakEvent $e){
    if (!$e->getPlayer()->isOp()) {
    $player = $e->getPlayer();
    if($this->break == false){
    $e->setCancelled(true);
    $player->sendMessage(T::GREEN."[TIP] ".T::GRAY."La Proteccion Esta Acivada");
    }
    }
    }

    public function onPlace(BlockPlaceEvent $e) {
    if (!$e->getPlayer()->isOp()) {
    if($this->break == false){
    $e->setCancelled(true);
    $player->sendMessage(T::GREEN."[TIP] ".T::GRAY."La Proteccion Esta Acivada");
    }
    }
    }

    public function onCha(PlayerChatEvent $event){
    if($event->isCancelled()){
	return;
    }
    $rank = new Config($this->getDataFolder() . "/rank.yml", Config::YAML);
    $player = $event->getPlayer();
    $name = $player->getName();
    $msg = $event->getMessage();
    if($this->globalmute === true){
    if(!$player->hasPermission("globalmute")){
    $event->setCancelled();
    $player->sendMessage(T::GRAY."[".T::GOLD."GlobalMute".T::GRAY."] ".T::GRAY."No Puedes Hablar!");
    }
    } else {
    if(!$player->hasPermission("spam")){
    if(!isset($this->spam[$player->getName()])){
    $lastTime = 0;
    } else {
    $lastTime = $this->spam[$player->getName()];
    }
    if(time() - $lastTime > 3){
    $this->spam[$player->getName()] = time();
    } else {
    $event->setCancelled(true);
    $player->sendMessage(T::GREEN."[TIP] ".T::GRAY."Prohibido Hacer Spam");
    }
    }
    } 
    if($player->hasPermission("default")){
    $event->setFormat(T::GRAY." ".$name.T::DARK_GRAY.T::BOLD." | ".T::RESET.T::GRAY.$msg);
    } 
    $r = $rank->get($player->getName());
    if($r==T::YELLOW."[Owner]"){
    $event->setFormat($r." ".T::AQUA.$name.T::DARK_GRAY.T::BOLD." | ".T::RESET.T::YELLOW.$msg);
    }else
    if($r==T::BLUE."[Host]"){
    $event->setFormat($r." ".T::DARK_AQUA.$name.T::DARK_GRAY.T::BOLD." | ".T::RESET.T::BLUE.$msg);
    }else
    if($r==T::DARK_PURPLE."[F]"){
    $event->setFormat($r." ".T::AQUA.$name.T::DARK_GRAY.T::BOLD." | ".T::RESET.T::DARK_PURPLE.$msg);
    }else
    if($r==T::LIGHT_PURPLE."[Famous]"){
    $event->setFormat($r." ".T::AQUA.$name.T::DARK_GRAY.T::BOLD." | ".T::RESET.T::LIGHT_PURPLE.$msg);
    }
    if($player->isSpectator()) {
    $event->setFormat(T::RED."[Spect] ".T::GRAY.$name.T::DARK_GRAY.T::BOLD." | ".T::RESET.T::GRAY.$msg);
    }
    }

    
   public function Times($int) {
   $m = floor($int / 60);
   $s = floor($int % 60);
   return (($m < 10 ? "0" : "") . $m . ":" . ($s < 10 ? "0" : "") . $s);
   }

   public function addBossBar(Player $player, $msg1, Int $time){
   $title = $msg1.T::AQUA.$this->Times($time);
   $pk = new AddPlayerPacket();
   $pk->uuid = UUID::fromRandom();
   $pk->x = $player->getX();
   $pk->y = $player->getY() - 5;
   $pk->z = $player->getZ();
   $pk->eid = 11000;
   $pk->speedX = 0;
   $pk->speedY = 0;
   $pk->speedZ = 0;
   $pk->yaw = 0;
   $pk->pitch = 0;
   $pk->item = Item::get(Item::AIR);
   $flags = 1 << Entity::DATA_FLAG_INVISIBLE;
   $flags |= 0 << Entity::DATA_FLAG_CAN_SHOW_NAMETAG;
   $flags |= 0 << Entity::DATA_FLAG_ALWAYS_SHOW_NAMETAG;
   $flags |= 1 << Entity::DATA_FLAG_IMMOBILE;
   $pk->metadata = [Entity::DATA_FLAGS =>[Entity::DATA_TYPE_LONG, $flags],
   Entity::DATA_NAMETAG =>[Entity::DATA_TYPE_STRING, $title],
   Entity::DATA_LEAD_HOLDER_EID => [Entity::DATA_TYPE_LONG, -1]];
   $player->dataPacket($pk);
   $pk = new BossEventPacket();
   $pk->eid = 11000;
   $player->dataPacket($pk);
   }

   public function oncana(PlayerInteractEvent $event) {
   $player = $event->getPlayer();
   $item = $player->getInventory()->getItemInHand();
   if ($item->getId() === $item::FISHING_ROD) {
   $nbt = new CompoundTag("", [
   "Pos" => new ListTag("Pos", [
   new DoubleTag("", $player->x),
   new DoubleTag("", $player->y + $player->getEyeHeight()),
   new DoubleTag("", $player->z)
   ]),
   "Motion" => new ListTag("Motion", [
   new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
   new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
   new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI))
   ]),
   "Rotation" => new ListTag("Rotation", [
   new FloatTag("", $player->yaw),
   new FloatTag("", $player->pitch)
   ]),
   ]);
   $f = 2;
   $snowball = Entity::createEntity("Snowball", $player->chunk, $nbt, $player, true);
   $snowball->setMotion($snowball->getMotion()->multiply($f));
   $snowball->getLevel()->addSound(new ClickSound(new Vector3($player->x, $player->y, $player->z, $player->getLevel())));
   }
   }
   }
     